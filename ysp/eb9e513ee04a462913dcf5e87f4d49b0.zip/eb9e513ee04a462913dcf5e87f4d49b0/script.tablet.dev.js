/*! Copyright(c) AllMobilize/YunShiPei -- Generate the date : 2017-04-05 10:02:47.450 */
/**
 * 注意：这个script.js是整个工程全局的脚本文件，会被加载到所有的页面中。 
 * 发布的正式版中，script.js 被编译成 script.js 文件
**/