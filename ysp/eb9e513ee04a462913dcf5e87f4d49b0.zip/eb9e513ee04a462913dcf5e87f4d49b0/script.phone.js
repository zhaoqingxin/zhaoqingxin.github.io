/*! Copyright(c) AllMobilize/YunShiPei -- Generate the date : 2018-04-09 17:16:56.703 */
/**
 * 注意：这个script.js是整个工程全局的脚本文件，会被加载到所有的页面中。 
 * 发布的正式版中，script.js 被编译成 script.js 文件
**/
var a = 10;